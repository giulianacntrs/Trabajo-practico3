  drop database if exists esteticas;
  create database esteticas;
  use esteticas;

  drop table if exists clientas;
  drop table if exists locales;
  drop table if exists tratamientos;
  drop table if exists empleadas;
  drop table if exists turnos;


  CREATE TABLE esteticas.clientas (
    idCliente INT NOT NULL AUTO_INCREMENT,
    nombreApellido VARCHAR(70) NULL,
    telefono INT NULL,
    mail VARCHAR(70) NULL,
    PRIMARY KEY (idCliente))
  ENGINE = InnoDB
  DEFAULT CHARACTER SET = utf8mb4
  COLLATE = utf8mb4_spanish_ci;

  drop table if exists locales;
  CREATE TABLE esteticas.locales (
    idLocal INT NOT NULL AUTO_INCREMENT,
    telefono INT NULL,
    mail VARCHAR(70) NULL,
    sucursal enum ('Belgrano', 'Caballito', 'Morón', 'Palermo', 'San Miguel'),
    direccion VARCHAR(70) NULL,
    PRIMARY KEY (idLocal));
    
    
    drop table if exists empleadas;
    CREATE TABLE esteticas.empleadas (
    idEmpleado INT NOT NULL AUTO_INCREMENT,
    nombreApellido VARCHAR(70) NULL,
    tipoTrabajo enum ('Manicura', 'Esteticista', 'Especialista en pestañas y cejas'),
    turno enum ('Mañana', 'Tarde'),
    PRIMARY KEY (idEmpleado));
    
    drop table if exists tratamientos;
    CREATE TABLE esteticas.tratamientos (
    idTratamiento INT NOT NULL AUTO_INCREMENT,
    tipoTratamiento enum ('Depilación Definitiva', 'Perfilado de cejas', 'Extensiones de pestañas', 
    'Electrodos', 'Criolipolisis', 'Uñas acrilicas', 'Esmaltado Semi/Kapping'),
    precio double NULL,
    descTratamiento VARCHAR(140) NULL,
    idEmpleado INT NULL,
    idLocal INT NULL,
    PRIMARY KEY (idTratamiento));
    
    drop table if exists turnos;
    CREATE TABLE esteticas.turnos (
    idTurno INT NOT NULL AUTO_INCREMENT,
    fecha DATE null,
    hora enum ('09:00hs', '09:30hs', '10:00hs', '10:30hs', '11:00hs', '11:30hs', '13:00hs', '13:30hs', '14:00hs', '14:30hs',
                '15:00hs','15:30hs', '16:00hs', '16:30hs', '17:00hs', '17:30hs', '18:00hs', '18:30hs', '19:00hs', '19:30hs'),
    precio double NULL,
    idEmpleado INT NULL,
    idLocal INT NULL,
    idCliente INT NULL,
    idTratamiento INT NULL,
    PRIMARY KEY (idTurno));
    
    alter table turnos 
    add constraint FK_turnos_idCliente
    foreign key (idCliente)
    references clientas(idCliente);
    
      alter table turnos 
    add constraint FK_turnos_idEmpleado
    foreign key (idEmpleado)
    references empleadas(idEmpleado);
    
    alter table turnos 
    add constraint FK_turnos_idLocal
    foreign key (idLocal)
    references locales(idLocal);
    
    alter table turnos 
    add constraint FK_turnos_idTrat
    foreign key (idTratamiento)
    references tratamientos(idTratamiento);

    insert into clientas VALUES
    -- id nombreApellido, tel, mail 
    (null, 'Maria Torres','1123456097','mariaestorres12@gmail.com'),
    (null, 'Eugenia Sanchez','1154667891','eugeniasanchez101@gmail.com'),
    (null, 'Noelia Peña','1155678234','noeliaspeña54@gmail.com'),
    (null, 'Camila Benitez ','1157690972','camibenitez34@gmail.com'),
    (null, 'Brenda Acuña','1145668094','brendaacuña334@gmail.com');


    insert into locales VALUES
    -- idlocal tel mail sucursal direccion
    (null, 47846543, 'esteticaperlabelgrano@gmail.com','Belgrano', 'Vidal 2371, Belgrano, CABA'),
    (null, 37986139, 'esteticaperlamoron@gmail.com','Morón', 'Rivadavia 18451, Moron, GBA'),
    (null, 49582549, 'esteticaperlacaballito@gmail.com','Caballito', 'Av. Rivadavia 4702 , Caballito, CABA'),
    (null, 57786139, 'esteticaperlapalermo@gmail.com','Palermo', 'Av. Santa Fe 3192, Palermo, CABA'),
    (null, 57346139, 'esteticaperlasanmiguel@gmail.com','San Miguel', 'Av. Presidente Pte. J. D. Perón 1153, San Miguel, GBA');
    
    insert into empleadas VALUES
  -- id, nombreApellido, tipo trabajo y turno
  (null, 'Carla Acosta','Manicura','Mañana'),
  (null, 'Sofia Casero','Esteticista','Mañana'),
  (null, 'Carmen Verdi','Especialista en pestañas y cejas','Mañana'),
  (null, 'Paloma Rodriguez','Manicura','Tarde'),
  (null, 'Iris Solis','Esteticista','Tarde');

  insert into tratamientos VALUES

  -- idempleeado, idlocal
  (null, 'Depilación Definitiva',750,'Precio dependiendo la zona. Precio por 3 zonas $1500, por 4 $1800, 
  por 5 zonas $2000, más de 6 zonas $2500',2,5),
  (null, 'Perfilado de cejas',500,'Perfilado personalizado por la profesional',3,4),
  (null, 'Extensiones de pestañas',1500,'2D, 3D, 4D',3,2),
  (null, 'Uñas acrilicas',1200,'Tamaño: Cortas, medias(1500) y xl(1800)',4,3),
  (null, 'Esmaltado Semi/Kapping',800,'Con piedras strass 150 por cada una. 
  Con nail art $250 agregado al precio base',1,1);

  insert into turnos VALUES
  --  precio,idEmpleado,idLocal,idCliente,idTratamiento
  (null,'12/10/22','09:00hs',1500,3,2,1,3), -- extensiones de pestañas
  (null,'12/10/22','10:30hs',500,3,4,2,2),  -- perfilado de cejas
  (null,'16/10/22','10:00hs',1500,1,2,3,3), -- uñas acrilicas
  (null,'16/10/22','16:30hs',800,4,4,4,5), -- semi
  (null,'17/10/22','09:00hs',2500,3,2,5,1); -- depilacion definitiva

  -- Queries
  -- Mostrar todos los turnos del dia 12/10/2022
  select * 
  from   turnos
  where  fecha='12/10/22';
  -- Mostrar todas las empleadas que trabajan en el sucursal de Morón
  select    e.nombreApellido as empleada,
            e.tipotrabajo  as 'Tipo de trabajo',
            l.sucursal as local
  from       empleadas e
  inner join turnos t on e.idempleado = t.idempleado
  inner join locales l on l.idlocal = t.idlocal
  where      t.idlocal = 2;

  -- Todas las clientas que se atienda el dia 16/10/2022
  select     c.nombreApellido as Clienta
  from       clientas c
  inner join turnos t on c.idcliente = t.idcliente
  where      fecha = '16/10/22';

  -- Todas las clientas que se hacen uñas acrilicas
  select     c.nombreApellido as clienta,
             l.sucursal as local
  from       clientas c
  inner join turnos t on c.idcliente = t.idcliente
  inner join locales l on l.idlocal = t.idlocal
  where      idTratamiento = 3;

  -- Todos los tratamiento que se hacen el dia 12/10/22
  select     tipoTratamiento as Tratamiento
  from       tratamientos r
  inner join turnos t on r.idtratamiento = t.idtratamiento
  where      fecha = '12/10/22';

  -- Todas las empleadas que trabajan en dia 16/10/22
  select     nombreApellido as empleada
  from       empleadas e
  inner join turnos t on e.idempleado = t.idempleado
  where      fecha = '16/10/22';
