package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Turno;
import ar.org.centro8.curso.java.trabajopractico3.enums.Hora;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TurnoRepository;

public class TurnoRepository implements I_TurnoRepository {
    private Connection conn;

    public TurnoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Turno> getAll() {
        List<Turno> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from turnos")) {
            while (rs.next()) {
                list.add(new Turno(
                        rs.getInt("idTurno"),
                        rs.getString("fecha"),
                        Hora.valueOf(rs.getString("hora")),
                        rs.getDouble("precio"),
                        rs.getInt("idEmpleada"),
                        rs.getInt("idLocal"),
                        rs.getInt("idClienta"),
                        rs.getInt("idTratamiento")));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void remove(Turno Turno) {
        if (Turno == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete into turnos (fecha, hora, precio, idEmpleada, idLocal, idTratamiento) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, Turno.getFecha());
            ps.setString(2, Turno.getHora().toString());
            ps.setDouble(3, Turno.getPrecio());
            ps.setInt(4, Turno.getIdEmpleada());
            ps.setInt(5, Turno.getIdLocal());
            ps.setInt(6, Turno.getIdTratamiento());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void save(Turno Turno) {
        if (Turno == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into turnos (fecha, hora, precio, idEmpleada, idLocal, idTratamiento) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, Turno.getFecha());
            ps.setString(2, Turno.getHora().toString());
            ps.setDouble(3, Turno.getPrecio());
            ps.setInt(4, Turno.getIdEmpleada());
            ps.setInt(5, Turno.getIdLocal());
            ps.setInt(6, Turno.getIdTratamiento());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                Turno.setIdTurno(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Turno Turno) {
        if (Turno == null) // fecha, hora, precio, idEmpleada, idLocal, idTratamiento
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update turnos set fecha=?, hora=?, precio=?, idEmpleada=?, idLocal=?, idTratamiento where idTurno=?")) {
            ps.setString(1, Turno.getFecha().toString());
            ps.setString(2, Turno.getHora().toString());
            ps.setDouble(3, Turno.getPrecio());
            ps.setInt(4, Turno.getIdEmpleada());
            ps.setInt(5, Turno.getIdLocal());
            ps.setInt(6, Turno.getIdTratamiento());

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
