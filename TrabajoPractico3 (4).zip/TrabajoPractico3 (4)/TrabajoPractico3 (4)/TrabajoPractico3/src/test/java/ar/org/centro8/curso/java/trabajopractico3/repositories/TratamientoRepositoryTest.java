package ar.org.centro8.curso.java.trabajopractico3.repositories;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.trabajopractico3.connector.Connector;
import ar.org.centro8.curso.java.trabajopractico3.entities.Tratamiento;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TratamientoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.TratamientoRepository;

public class TratamientoRepositoryTest {

    I_TratamientoRepository tratamientoRepository = new TratamientoRepository(Connector.getConnection());

    @Test
    void testSave() {
        Tratamiento tratamiento1 = new Tratamiento("DepilacionDefinitiva", 950, "ooo", 1, 1);
        Tratamiento tratamiento2 = new Tratamiento("DepilacionDefinitiva", 950, "ooo", 1, 1);
        tratamientoRepository.save(tratamiento1);
        tratamientoRepository.save(tratamiento2);

        assertEquals(tratamiento1.getIdTratamiento() > 0, true);
        assertEquals(tratamiento1.getIdTratamiento(), tratamiento2.getIdTratamiento() - 1);
    }

    @Test
    void testGetAll() {
        assertEquals(tratamientoRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = tratamientoRepository.getAll().size();
        tratamientoRepository.remove(tratamientoRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = tratamientoRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = tratamientoRepository.getAll().size();
        Tratamiento tratamiento=tratamientoRepository.getAll().get(cantidad-1);
        tratamiento.setTipoTratamiento("Depilacion Definitiva");
        tratamiento.setPrecio(950);
        tratamiento.setdescripcion("ooo");
        tratamiento.setIdEmpleada(1);
        tratamiento.setIdLocal(1);
        tratamientoRepository.update(tratamiento);
        Tratamiento tratamiento2 = tratamientoRepository.getAll().get(cantidad - 1);

        assertEquals(tratamiento.getTipoTratamiento(), tratamiento2.getTipoTratamiento());
        assertEquals(tratamiento.getPrecio(), tratamiento2.getPrecio());
        assertEquals(tratamiento.getdescripcion(), tratamiento2.getdescripcion());
        assertEquals(tratamiento.getIdEmpleada(), tratamiento2.getIdEmpleada());
        assertEquals(tratamiento.getIdLocal(), tratamiento2.getIdLocal());

    }
}
