package ar.org.centro8.curso.java.trabajopractico3.entities;


public class Tratamiento {
    private int idTratamiento;
    private String tipoTratamiento;
    private double precio;
    private String descripcion;
    private int idEmpleada;
    private int idLocal;

    public Tratamiento() {
    }

    public Tratamiento(String tipoTratamiento, double precio, String descripcion, int idEmpleada,
            int idLocal) {
        this.tipoTratamiento = tipoTratamiento;
        this.precio = precio;
        this.descripcion = descripcion;
        this.idEmpleada = idEmpleada;
        this.idLocal = idLocal;
    }

    public Tratamiento(int idTratamiento, String tipoTratamiento, double precio, String descripcion,
            int idEmpleada, int idLocal) {
        this.idTratamiento = idTratamiento;
        this.tipoTratamiento = tipoTratamiento;
        this.precio = precio;
        this.descripcion = descripcion;
        this.idEmpleada = idEmpleada;
        this.idLocal = idLocal;
    }

    @Override
    public String toString() {
        return "Tratamiento [idTratamiento=" + idTratamiento + ", tipoTratamiento=" + tipoTratamiento + ", precio="
                + precio
                + ", descripcion=" + descripcion + ", idEmpleada=" + idEmpleada + ", idLocal=" + idLocal + "]";
    }

    public int getIdTratamiento() {
        return idTratamiento;
    }

    public void setIdTratamiento(int idTratamiento) {
        this.idTratamiento = idTratamiento;
    }

    public String getTipoTratamiento() {
        return tipoTratamiento;
    }

    public void setTipoTratamiento(String tipoTratamiento) {
        this.tipoTratamiento = tipoTratamiento;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getdescripcion() {
        return descripcion;
    }

    public void setdescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getIdEmpleada() {
        return idEmpleada;
    }

    public void setIdEmpleada(int idEmpleada) {
        this.idEmpleada = idEmpleada;
    }

    public int getIdLocal() {
        return idLocal;
    }

    public void setIdLocal(int idLocal) {
        this.idLocal = idLocal;
    }

}
