package ar.org.centro8.curso.java.trabajopractico3.entities;


import ar.org.centro8.curso.java.trabajopractico3.enums.Hora;

public class Turno {
    private int idTurno;
    private String fecha;
    private Hora hora;
    private double precio;
    private int idEmpleada;
    private int idLocal;
    private int idClienta;
    private int idTratamiento;

    public Turno() {
    }

    public Turno(String fecha, Hora hora, double precio, int idEmpleada, int idLocal, int idClienta,
            int idTratamiento) {
        this.fecha = fecha;
        this.hora = hora;
        this.precio = precio;
        this.idEmpleada = idEmpleada;
        this.idLocal = idLocal;
        this.idClienta = idClienta;
        this.idTratamiento = idTratamiento;
    }

    public Turno(int idTurno, String string, Hora hora, double precio, int idEmpleada, int idLocal, int idClienta,
            int idTratamiento) {
        this.idTurno = idTurno;
        this.fecha = string;
        this.hora = hora;
        this.precio = precio;
        this.idEmpleada = idEmpleada;
        this.idLocal = idLocal;
        this.idClienta = idClienta;
        this.idTratamiento = idTratamiento;
    }

    @Override
    public String toString() {
        return "Turno [idTurno=" + idTurno + ", fecha=" + fecha + ", hora=" + hora + ", precio=" + precio
                + ", idEmpleada=" + idEmpleada + ", idLocal=" + idLocal + ", idClienta=" + idClienta
                + ", idTratamiento=" + idTratamiento + "]";
    }

    public int getIdTurno() {
        return idTurno;
    }

    public void setIdTurno(int idTurno) {
        this.idTurno = idTurno;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Hora getHora() {
        return hora;
    }

    public void setHora(Hora hora) {
        this.hora = hora;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getIdEmpleada() {
        return idEmpleada;
    }

    public void setIdEmpleada(int idEmpleada) {
        this.idEmpleada = idEmpleada;
    }

    public int getIdLocal() {
        return idLocal;
    }

    public void setIdLocal(int idLocal) {
        this.idLocal = idLocal;
    }

    public int getIdClienta() {
        return idClienta;
    }

    public void setIdClienta(int idClienta) {
        this.idClienta = idClienta;
    }

    public int getIdTratamiento() {
        return idTratamiento;
    }

    public void setIdTratamiento(int idTratamiento) {
        this.idTratamiento = idTratamiento;
    }

}
