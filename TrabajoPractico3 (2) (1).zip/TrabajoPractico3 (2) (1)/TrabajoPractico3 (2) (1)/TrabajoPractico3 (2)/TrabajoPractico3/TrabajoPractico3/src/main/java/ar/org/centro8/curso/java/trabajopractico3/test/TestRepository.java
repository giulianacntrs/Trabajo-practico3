package ar.org.centro8.curso.java.trabajopractico3.test;

import java.sql.Connection;
import ar.org.centro8.curso.java.trabajopractico3.connector.Connector;
import ar.org.centro8.curso.java.trabajopractico3.entities.Clienta;
import ar.org.centro8.curso.java.trabajopractico3.entities.Empleada;
import ar.org.centro8.curso.java.trabajopractico3.entities.Local;
import ar.org.centro8.curso.java.trabajopractico3.entities.Tratamiento;
import ar.org.centro8.curso.java.trabajopractico3.entities.Turno;
import ar.org.centro8.curso.java.trabajopractico3.enums.Hora;
import ar.org.centro8.curso.java.trabajopractico3.enums.Sucursal;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTratamiento;
import ar.org.centro8.curso.java.trabajopractico3.enums.TurnoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_ClientaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_EmpleadaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TratamientoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TurnoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.ClientaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.EmpleadaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.TratamientoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.TurnoRepository;

public class TestRepository {
        public static void main(String[] args) {
                Connection conn = Connector.getConnection();
                
                  I_ClientaRepository clientaRepository = new ClientaRepository(conn);
                  Clienta clienta = new Clienta("Maria Salas", "1123456238",
                  "mariasalas201@gmail.com");
                  clientaRepository.save(clienta);
                  System.out.println(clienta);

                  Clienta clienta2 = new Clienta("Maria Gomez", "ooo",
                  "ooo");
                  clientaRepository.save(clienta2);
                  System.out.println(clienta2);
                  
                  clientaRepository.remove(clientaRepository.getByIdClienta(22));
                  
                  clienta = clientaRepository.getByIdClienta(2);


                  if (clienta != null && clienta.getidClienta() != 0) {
                  clienta.setNombreApellido("Erica Costas");
                  clienta.setMail("ericostas233@hotmail.com");
                  clientaRepository.update(clienta);
                  }
                  
                  System.out.println("-------------------------------------");
                  clientaRepository.getAll().forEach(System.out::println);
                  
                  System.out.println("-------------------------------------");
                  clientaRepository
                  .getLikeNombreApellido("as")
                  .forEach(System.out::println);
                  System.out.println("-------------------------------------");
                  clientaRepository
                  .getLikeMail("gmail")
                  .forEach(System.out::println);
                  
                  System.out.println("-------------------------------------");
                 
                  I_EmpleadaRepository empleadaRepository = new EmpleadaRepository(conn);
                  Empleada empleada = new Empleada("Ailen Torres", TipoTrabajo.Manicura,
                  TurnoTrabajo.Mañana);
                  empleadaRepository.save(empleada);
                  System.out.println(empleada);
                  
                  Empleada empleada2 = new Empleada("Ailen Campos", TipoTrabajo.Manicura,
                  TurnoTrabajo.Mañana);
                  empleadaRepository.save(empleada2);
                  System.out.println(empleada2);
                  
                  empleadaRepository.remove(empleadaRepository.getByIdEmpleada(27));
                  
                  empleada = empleadaRepository.getByIdEmpleada(10);
                  if (empleada != null && empleada.getIdEmpleada() != 0) {
                  empleada.setNombreApellido("Sabrina Sosa");
                  empleada.setTipoTrabajo(TipoTrabajo.Manicura);
                  empleadaRepository.update(empleada);
                  }
                  System.out.println("-------------------------------------");
                  empleadaRepository.getAll().forEach(System.out::println);
                  
                  System.out.println("-------------------------------------");
                  empleadaRepository
                  .getLikeNombreApellido("Sab")
                  .forEach(System.out::println);
                  System.out.println("-------------------------------------");
                  empleadaRepository
                  .getLikeTipoTrabajo(TipoTrabajo.Esteticista)
                  .forEach(System.out::println);
                  
                  System.out.println("-------------------------------------");
                  
                   I_LocalRepository localRepository = new LocalRepository(conn);
                  Local local = new Local("44585563", "esteticacaballito@gmail.com",
                  Sucursal.Caballito);
                  localRepository.save(local);
                  System.out.println(local);
                  
                  localRepository.remove(localRepository.getByIdLocal(6));
                  
                  local = localRepository.getByIdLocal(3);
                  if (local != null && local.getIdLocal() != 0) {
                  local.setMail("steticacaballito@gmail.com2");
                  local.setSucursal(Sucursal.Caballito);
                  localRepository.update(local);
                  }
                  System.out.println("-------------------------------------");
                  localRepository.getAll().forEach(System.out::println);
                  
                  System.out.println("-------------------------------------");
                  localRepository
                  .getLikeMail("belgrano")
                  .forEach(System.out::println);
                  System.out.println("-------------------------------------");
                  localRepository
                  .getLikeSucursal(Sucursal.Caballito)
                  .forEach(System.out::println);
                 

                I_TratamientoRepository tratamientoRepository = new TratamientoRepository(conn);
                Tratamiento tratamiento = new Tratamiento(TipoTratamiento.PerfiladoDeCejas, 750,
                                "Perfilado acorde al tipo de rostro", 2, 2);
                tratamientoRepository.save(tratamiento);
                System.out.println(tratamiento);

                tratamientoRepository.remove(tratamientoRepository.getByIdTratamiento(35));

                tratamiento = tratamientoRepository.getByIdTratamiento(3);
                if (tratamiento != null && tratamiento.getIdTratamiento() != 0) {
                        tratamiento.setTipoTratamiento(TipoTratamiento.ExtensionesDePestañas);
                        tratamiento.setdescripcion("2D,3D,4D");
                        tratamientoRepository.update(tratamiento);
                }
                System.out.println("-------------------------------------");
                tratamientoRepository.getAll().forEach(System.out::println);

                System.out.println("-------------------------------------");
                tratamientoRepository
                                .getLikeTipoTratamiento(TipoTratamiento.ExtensionesDePestañas)
                                .forEach(System.out::println);

                System.out.println("-------------------------------------");
                tratamientoRepository
                                .getLikedescripcion("2D")
                                .forEach(System.out::println);

                System.out.println("-------------------------------------");

                
                  I_TurnoRepository turnoRepository = new TurnoRepository(conn);
                  Turno turno = new Turno("2022-11-04", Hora.h1100, 1200, 2, 2, 2, 2);
                  turnoRepository.save(turno);
                  System.out.println(turno);
                  
                  Turno turno2 = new Turno("2022-11-05", Hora.h1000, 1400, 3, 3, 3, 3);
                  turnoRepository.save(turno2);
                  System.out.println(turno2);
                  
                  turnoRepository.remove(turnoRepository.getByIdTurno(9));
                  
                  turno = turnoRepository.getByIdTurno(3);
                  if (turno != null && turno.getIdTurno() != 0) {
                  turno.setFecha("2022-11-15");
                  turno.setHora(Hora.h1000);
                  turnoRepository.update(turno);
                  }
                  System.out.println("-------------------------------------");
                  turnoRepository.getAll().forEach(System.out::println);
                  
                  System.out.println("-------------------------------------");
                  turnoRepository
                  .getLikeFecha("2022-11-04")
                  .forEach(System.out::println);
                  
                  System.out.println("-------------------------------------");
                  turnoRepository
                  .getLikeHora(Hora.h0900)
                  .forEach(System.out::println); 
                 
        }
}
