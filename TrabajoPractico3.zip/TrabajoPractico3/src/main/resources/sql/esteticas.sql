  drop database if exists esteticas;
  create database esteticas;
  use esteticas;

  drop table if exists clientas;
  drop table if exists locales;
  drop table if exists tratamientos;
  drop table if exists empleadas;
  drop table if exists turnos;


  CREATE TABLE esteticas.clientas (
    idClienta INT NOT NULL AUTO_INCREMENT,
    nombreApellido VARCHAR(70) NULL,
    telefono INT NULL,
    mail VARCHAR(70) NULL,
    PRIMARY KEY (idClienta))
  ENGINE = InnoDB
  DEFAULT CHARACTER SET = utf8mb4
  COLLATE = utf8mb4_spanish_ci;

  drop table if exists locales;
  CREATE TABLE esteticas.locales (
    idLocal INT NOT NULL AUTO_INCREMENT,
    telefono INT NULL,
    mail VARCHAR(70) NULL,
    sucursal enum (Belgrano, Caballito, Morón, Palermo, SanMiguel),
    direccion VARCHAR(70) NULL,
    PRIMARY KEY (idLocal));
    
    
    drop table if exists empleadas;
    CREATE TABLE esteticas.empleadas (
    idEmpleada INT NOT NULL AUTO_INCREMENT,
    nombreApellido VARCHAR(70) NULL,
    tipoTrabajo enum (Manicura, Esteticista, Especialista en pestañas y cejas),
    turno enum (Mañana, Tarde),
    PRIMARY KEY (idEmpleada));
    
    drop table if exists tratamientos;
    CREATE TABLE esteticas.tratamientos (
    idTratamiento INT NOT NULL AUTO_INCREMENT,
    tipoTratamiento enum (Depilación Definitiva, Perfilado de cejas, Extensiones de pestañas, 
    Electrodos, Criolipolisis, Uñas acrilicas, Esmaltado Semi/Kapping),
    precio double NULL,
    descTratamiento VARCHAR(140) NULL,
    idEmpleada INT NULL,
    idLocal INT NULL,
    PRIMARY KEY (idTratamiento));
    
    drop table if exists turnos;
    CREATE TABLE esteticas.turnos (
    idTurno INT NOT NULL AUTO_INCREMENT,
    fecha DATE null,
    hora enum (h0900, h0930, h1000, h1030, h1100, h1130, h1300, h1330, h1400, 
    h1430, h1500,h1530, h1600, h1630, h1700, h1730, h1800, h1830, h1900, h1930),
    precio double NULL,
    idEmpleada INT NULL,
    idLocal INT NULL,
    idClienta INT NULL,
    idTratamiento INT NULL,
    PRIMARY KEY (idTurno));
    
    alter table turnos 
    add constraint FK_turnos_idClienta
    foreign key (idClienta)
    references clientas(idClienta);
    
      alter table turnos 
    add constraint FK_turnos_idEmpleada
    foreign key (idEmpleada)
    references empleadas(idEmpleada);
    
    alter table turnos 
    add constraint FK_turnos_idLocal
    foreign key (idLocal)
    references locales(idLocal);
    
    alter table turnos 
    add constraint FK_turnos_idTrat
    foreign key (idTratamiento)
    references tratamientos(idTratamiento);

