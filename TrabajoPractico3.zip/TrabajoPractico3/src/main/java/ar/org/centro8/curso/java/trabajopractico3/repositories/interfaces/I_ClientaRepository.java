package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;
import ar.org.centro8.curso.java.trabajopractico3.entities.Clienta;
import java.util.ArrayList;
import java.util.List;


public interface I_ClientaRepository {
  void save (Clienta clienta);     //insert
  void remove (Clienta clienta);   //delete
  void update (Clienta clienta);   //update

   default Clienta getByIdClienta(int idClienta){
    return getAll()
        .stream()
        .filter(c->c.getidClienta()==idClienta)
        .findAny()
        .orElse(new Clienta());        
} 
List<Clienta> getAll();
}
