package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

public class LocalRepository {
    
}
