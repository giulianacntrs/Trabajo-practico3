package ar.org.centro8.curso.java.trabajopractico3.entities;

import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTrabajo;

public class Empleada {
    private int idEmpleada;
    private String nombreApellido;
    private TipoTrabajo tipoTrabajo;
    private Turno turno;


    public Empleada (){}

    public Empleada(String nombreApellido, TipoTrabajo tipoTrabajo, Turno turno) {
        this.nombreApellido = nombreApellido;
        this.tipoTrabajo = tipoTrabajo;
        this.turno = turno;
    }

    public Empleada(int idEmpleada, String nombreApellido, TipoTrabajo tipoTrabajo, Turno turno) {
        this.idEmpleada = idEmpleada;
        this.nombreApellido = nombreApellido;
        this.tipoTrabajo = tipoTrabajo;
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Empleada [idEmpleada=" + idEmpleada + ", nombreApellido=" + nombreApellido + ", tipoTrabajo="
                + tipoTrabajo + ", turno=" + turno + "]";
    }

    public int getIdEmpleada() {
        return idEmpleada;
    }

    public void setIdEmpleada(int idEmpleada) {
        this.idEmpleada = idEmpleada;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }

    public TipoTrabajo getTipoTrabajo() {
        return tipoTrabajo;
    }

    public void setTipoTrabajo(TipoTrabajo tipoTrabajo) {
        this.tipoTrabajo = tipoTrabajo;
    }

    public Turno getTurno() {
        return turno;
    }

    public void setTurno(Turno turno) {
        this.turno = turno;
    }
 
    
}
