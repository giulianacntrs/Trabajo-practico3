package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmpleadaRepository {
    private Connection conn;

    public EmpleadaRepository(Connection conn) {
        this.conn = conn;
} 
}
