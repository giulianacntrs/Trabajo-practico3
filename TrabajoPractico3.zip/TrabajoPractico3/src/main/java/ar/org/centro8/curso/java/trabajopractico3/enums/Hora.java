package ar.org.centro8.curso.java.trabajopractico3.enums;

public enum Hora {
  /* (09:00hs), 
  09:30hs, 
  10:00hs, 
  10:30hs, 
  11:00hs, 
  11:30hs, 
  13:00hs, 
  13:30hs, 
  14:00hs, 
  14:30hs,
  15:00hs,
  15:30hs, 
  16:00hs, 
  16:30hs, 
  17:00hs, 
  17:30hs, 
  18:00hs, 
  18:30hs, 
  19:00hs, 
  19:30hs */
    
}
