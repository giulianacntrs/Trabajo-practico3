package ar.org.centro8.curso.java.trabajopractico3.enums;

public enum Hora {
  h0900, 
  h0930, 
  h1000, 
  h1030, 
  h1100, 
  h1130, 
  h1300, 
  h1330, 
  h1400, 
  h1430,
  h1500,
  h1530, 
  h1600, 
  h1630, 
  h1700, 
  h1730, 
  h1800, 
  h1830, 
  h1900, 
  h1930
    
}
