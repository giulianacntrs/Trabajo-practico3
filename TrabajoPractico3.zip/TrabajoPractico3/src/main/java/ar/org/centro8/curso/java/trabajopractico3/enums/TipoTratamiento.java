package ar.org.centro8.curso.java.trabajopractico3.enums;

public enum TipoTratamiento {
    
}
