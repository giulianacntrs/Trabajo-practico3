package ar.org.centro8.curso.java.trabajopractico3.entities;

public class Clienta {
 private int idClienta;
 private String nombreApellido;
 private int telefono;
 private String mail;

public Clienta() {}

public Clienta(String nombreApellido, int telefono, String mail) {
    this.nombreApellido = nombreApellido;
    this.telefono = telefono;
    this.mail = mail;
}

public Clienta(int idClienta, String nombreApellido, int telefono, String mail) {
    this.idClienta = idClienta;
    this.nombreApellido = nombreApellido;
    this.telefono = telefono;
    this.mail = mail;
}



@Override
public String toString() {
    return "Clienta [idClienta=" + idClienta + ", nombreApellido=" + nombreApellido + ", telefono=" + telefono
            + ", mail=" + mail + "]";
}

public int getidClienta() {
    return idClienta;
}

public void setidClienta(int idClienta) {
    this.idClienta = idClienta;
}

public String getNombreApellido() {
    return nombreApellido;
}

public void setNombreApellido(String nombreApellido) {
    this.nombreApellido = nombreApellido;
}

public int getTelefono() {
    return telefono;
}

public void setTelefono(int telefono) {
    this.telefono = telefono;
}

public String getMail() {
    return mail;
}

public void setMail(String mail) {
    this.mail = mail;
}





}
