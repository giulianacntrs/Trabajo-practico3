package ar.org.centro8.curso.java.trabajopractico3.entities;

public class Clienta {
 private int idEmpleada;
 private String nombreApellido;
 private int telefono;
 private String mail;

public Clienta() {}

public Clienta(String nombreApellido, int telefono, String mail) {
    this.nombreApellido = nombreApellido;
    this.telefono = telefono;
    this.mail = mail;
}

public Clienta(int idEmpleada, String nombreApellido, int telefono, String mail) {
    this.idEmpleada = idEmpleada;
    this.nombreApellido = nombreApellido;
    this.telefono = telefono;
    this.mail = mail;
}



@Override
public String toString() {
    return "Clienta [idEmpleada=" + idEmpleada + ", nombreApellido=" + nombreApellido + ", telefono=" + telefono
            + ", mail=" + mail + "]";
}

public int getIdEmpleada() {
    return idEmpleada;
}

public void setIdEmpleada(int idEmpleada) {
    this.idEmpleada = idEmpleada;
}

public String getNombreApellido() {
    return nombreApellido;
}

public void setNombreApellido(String nombreApellido) {
    this.nombreApellido = nombreApellido;
}

public int getTelefono() {
    return telefono;
}

public void setTelefono(int telefono) {
    this.telefono = telefono;
}

public String getMail() {
    return mail;
}

public void setMail(String mail) {
    this.mail = mail;
}





}
