package ar.org.centro8.curso.java.trabajopractico3.utils;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.trabajopractico3.connector.Connector;
import ar.org.centro8.curso.java.trabajopractico3.entities.Clienta;
import ar.org.centro8.curso.java.trabajopractico3.entities.Empleada;
import ar.org.centro8.curso.java.trabajopractico3.entities.Local;
import ar.org.centro8.curso.java.trabajopractico3.entities.Tratamiento;
import ar.org.centro8.curso.java.trabajopractico3.entities.Turno;
import ar.org.centro8.curso.java.trabajopractico3.enums.Hora;
import ar.org.centro8.curso.java.trabajopractico3.enums.Sucursal;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTratamiento;
import ar.org.centro8.curso.java.trabajopractico3.enums.TurnoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_ClientaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_EmpleadaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TratamientoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TurnoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.ClientaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.EmpleadaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.TratamientoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.TurnoRepository;

@Controller
public class WebController {
    private String mensajeClientas = "Ingrese una nueva clienta";
    private String mensajeEmpleadas = "Ingrese una nueva empleada";
    private String mensajeLocales = "Ingrese una nueva local";
    private String mensajeTratamientos = "Ingrese un nuevo tratamientos";
    private String mensajeTurnos = "Ingrese un nuevo turno";

    private I_ClientaRepository clientaRepository = new ClientaRepository(Connector.getConnection());
    private I_EmpleadaRepository empleadaRepository = new EmpleadaRepository(Connector.getConnection());
    private I_LocalRepository localRepository = new LocalRepository(Connector.getConnection());
    private I_TratamientoRepository tratamientoRepository = new TratamientoRepository(Connector.getConnection());
    private I_TurnoRepository turnoRepository = new TurnoRepository(Connector.getConnection());

    @GetMapping("/")
    public String webMain() {
        return "index";
    }

    @GetMapping("/clientas")
    public String getWebClientas(
            @RequestParam(name = "buscarNombreApellido", required = false, defaultValue = "") String buscarNombreApellido,
            Model model) {
        model.addAttribute("clienta", new Clienta());
        model.addAttribute("mensajeClientas", mensajeClientas);
        model.addAttribute("all", clientaRepository.getAll());
        model.addAttribute("likeNombreApellido", clientaRepository.getLikeNombreApellido(buscarNombreApellido));
        return "clientas";

    }

    @GetMapping("/empleadas")
    public String getWebEmpleadas(
            @RequestParam(name = "buscarTipoTrabajo", required = false, defaultValue = "") TipoTrabajo buscarTipoTrabajo,
            Model model) {
        model.addAttribute("tipoTrabajo", List.of(TipoTrabajo.values()));
        model.addAttribute("turnoTrabajo", List.of(TurnoTrabajo.values()));
        model.addAttribute("empleada", new Empleada());
        model.addAttribute("mensajeEmpleadas", mensajeEmpleadas);
        model.addAttribute("all", empleadaRepository.getAll());
        model.addAttribute("likeTipoTrabajo", empleadaRepository.getLikeTipoTrabajo(buscarTipoTrabajo));
        return "empleadas";
    }

    @GetMapping("/locales")
    public String getWebLocales(
            @RequestParam(name = "buscarSucursal", required = false, defaultValue = "") Sucursal buscarSucursal,
            Model model) {
        model.addAttribute("sucursal", List.of(Sucursal.values()));
        model.addAttribute("local", new Local());
        model.addAttribute("mensajeLocales", mensajeLocales);
        model.addAttribute("all", localRepository.getAll());
        model.addAttribute("likeSucursal", localRepository.getLikeSucursal(buscarSucursal));
        return "locales";
    }

    @GetMapping("/tratamientos")
    public String getWebTratamientos(
            @RequestParam(name = "buscarTipoTratamiento", required = false, defaultValue = "") TipoTratamiento buscarTipoTratamiento,
            Model model) {
        model.addAttribute("tipoTratamiento", List.of(TipoTratamiento.values()));
        model.addAttribute("tratamiento", new Tratamiento());
        model.addAttribute("mensajeTratamientos", mensajeTratamientos);
        model.addAttribute("all", tratamientoRepository.getAll());
        model.addAttribute("likeTipoTratamiento", tratamientoRepository.getLikeTipoTratamiento(buscarTipoTratamiento));
        return "tratamientos";
    }

    @GetMapping("/turnos")
    public String getWebTurnos(
            @RequestParam(name = "buscarFecha", required = false, defaultValue = "") String buscarFecha,
            Model model) {
        model.addAttribute("hora", List.of(Hora.values()));
        model.addAttribute("turno", new Turno());
        model.addAttribute("mensajeTurnos", mensajeTurnos);
        model.addAttribute("all", turnoRepository.getAll());
        model.addAttribute("likeFecha", turnoRepository.getLikeFecha(buscarFecha));
        return "turnos";
    }

    @PostMapping("/saveClienta")
    public String saveClienta(@ModelAttribute Clienta clienta) {
        System.out.println("*************************************************************************");
        System.out.println(clienta);
        System.out.println("*************************************************************************");
        try {
            clientaRepository.save(clienta);
            mensajeClientas = "Se ingreso una nueva clienta id: " + clienta.getidClienta();
        } catch (Exception e) {
            mensajeClientas = "Ocurrio un error!";
        }
        return "redirect:clientas";
    }

    @PostMapping("/saveEmpleada")
    public String saveEmpleada(@ModelAttribute Empleada empleada) {
        System.out.println("*************************************************************************");
        System.out.println(empleada);
        System.out.println("*************************************************************************");

        try {
            empleadaRepository.save(empleada);
            mensajeEmpleadas = "Se ingreso una nueva empleada id: " + empleada.getIdEmpleada();
        } catch (Exception e) {
            mensajeEmpleadas = "Ocurrio un error!";
        }
        return "redirect:empleadas";

    }

    @PostMapping("/saveLocal")
    public String saveLocal(@ModelAttribute Local local) {
        System.out.println("*************************************************************************");
        System.out.println(local);
        System.out.println("*************************************************************************");

        try {
            localRepository.save(local);
            mensajeLocales = "Se ingreso un nuevo local id: " + local.getIdLocal();
        } catch (Exception e) {
            mensajeLocales = "Ocurrio un error!";
        }
        return "redirect:locales";

    }

    @PostMapping("/saveTratamiento")
    public String saveTratamiento(@ModelAttribute Tratamiento tratamiento) {
        System.out.println("*************************************************************************");
        System.out.println(tratamiento);
        System.out.println("*************************************************************************");

        try {
            tratamientoRepository.save(tratamiento);
            mensajeTratamientos = "Se ingreso un nuevo tratamiento id: " + tratamiento.getIdTratamiento();
        } catch (Exception e) {
            mensajeTratamientos = "Ocurrio un error!";
        }
        return "redirect:tratamientos";

    }

    @PostMapping("/saveTurno")
    public String saveTurno(@ModelAttribute Turno turno) {
        System.out.println("*************************************************************************");
        System.out.println(turno);
        System.out.println("*************************************************************************");

        try {
            turnoRepository.save(turno);
            mensajeTurnos = "Se ingreso un nuevo turno id: " + turno.getIdTurno();
        } catch (Exception e) {
            mensajeTurnos = "Ocurrio un error!";
        }
        return "redirect:turnos";

    }
}