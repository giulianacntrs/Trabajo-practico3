package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Clienta;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_ClientaRepository;

public class ClientaRepository {
    private Connection conn;

    public ClientaRepository(Connection conn) {
        this.conn = conn;
}
}
