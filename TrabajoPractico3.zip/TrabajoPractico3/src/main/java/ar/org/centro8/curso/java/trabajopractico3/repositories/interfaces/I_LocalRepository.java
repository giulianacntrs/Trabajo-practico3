package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;

import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Local;

public interface I_LocalRepository {
    void save (Local local);
    void remove (Local local);
    void update (Local local);

    default Local GetByIdLocal (int idLocal){
    return getAll()
    .stream()
    .filter(l->l.getIdLocal()==idLocal)
    .findAny()
    .orElse(new Local());

    }
  List<Local> getAll();
}
