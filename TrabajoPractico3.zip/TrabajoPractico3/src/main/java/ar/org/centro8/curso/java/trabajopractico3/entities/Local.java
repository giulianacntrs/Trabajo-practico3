package ar.org.centro8.curso.java.trabajopractico3.entities;

import ar.org.centro8.curso.java.trabajopractico3.enums.Sucursal;

public class Local {

private int idLocal;
private int telefono;
private String mail;
private Sucursal sucursal;

public  Local(){}

public Local(int telefono, String mail, Sucursal sucursal) {
    this.telefono = telefono;
    this.mail = mail;
    this.sucursal = sucursal;
}

public Local(int idLocal, int telefono, String mail, Sucursal sucursal) {
    this.idLocal = idLocal;
    this.telefono = telefono;
    this.mail = mail;
    this.sucursal = sucursal;
}

@Override
public String toString() {
    return "Empleada [idLocal=" + idLocal + ", telefono=" + telefono + ", mail=" + mail + ", sucursal=" + sucursal
            + "]";
}

public int getIdLocal() {
    return idLocal;
}

public void setIdLocal(int idLocal) {
    this.idLocal = idLocal;
}

public int getTelefono() {
    return telefono;
}

public void setTelefono(int telefono) {
    this.telefono = telefono;
}

public String getMail() {
    return mail;
}

public void setMail(String mail) {
    this.mail = mail;
}

public Sucursal getSucursal() {
    return sucursal;
}

public void setSucursal(Sucursal sucursal) {
    this.sucursal = sucursal;
}



}
