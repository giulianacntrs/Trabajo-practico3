package ar.org.centro8.curso.java.trabajopractico3.repositories;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.trabajopractico3.connector.Connector;
import ar.org.centro8.curso.java.trabajopractico3.entities.Clienta;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_ClientaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.ClientaRepository;

public class ClientaRepositoryTest {

    I_ClientaRepository clientaRepository = new ClientaRepository(Connector.getConnection());

    @Test
    void testSave() {
        Clienta clienta1 = new Clienta("ooo", "ooo", "ooo");
        Clienta clienta2 = new Clienta("ooo", "ooo", "ooo");
        clientaRepository.save(clienta1);
        clientaRepository.save(clienta2);

        assertEquals(clienta1.getidClienta() > 0, true);
        assertEquals(clienta1.getidClienta(), clienta2.getidClienta() - 1); //
    }

    @Test
    void testGetAll() {
        assertEquals(clientaRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = clientaRepository.getAll().size();
        clientaRepository.remove(clientaRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = clientaRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = clientaRepository.getAll().size();
        Clienta clienta = clientaRepository.getAll().get(cantidad - 1);
        clienta.setNombreApellido("ooo");
        clienta.setTelefono("ooo");
        clienta.setMail("ooo");
        clientaRepository.update(clienta);
        Clienta clienta2 = clientaRepository.getAll().get(cantidad - 1);

        assertEquals(clienta.getNombreApellido(), clienta2.getNombreApellido());
        assertEquals(clienta.getTelefono(), clienta2.getTelefono());
        assertEquals(clienta.getMail(), clienta2.getMail());

    }
}
