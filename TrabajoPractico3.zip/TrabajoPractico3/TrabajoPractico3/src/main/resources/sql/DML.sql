  use esteticas;
      insert into clientas VALUES
    -- id nombreApellido, tel, mail 
    (null, Maria Torres,1123456097,mariaestorres12@gmail.com),
    (null, Eugenia Sanchez,1154667891,eugeniasanchez101@gmail.com),
    (null, Noelia Peña,1155678234,noeliaspeña54@gmail.com),
    (null, Camila Benitez ,1157690972,camibenitez34@gmail.com),
    (null, Brenda Acuña,1145668094,brendaacuña334@gmail.com);


    insert into locales VALUES
    -- idlocal tel mail sucursal direccion
    (null, 47846543, esteticaperlabelgrano@gmail.com,Belgrano, Vidal 2371, Belgrano, CABA),
    (null, 37986139, esteticaperlamoron@gmail.com,Morón, Rivadavia 18451, Moron, GBA),
    (null, 49582549, esteticaperlacaballito@gmail.com,Caballito, Av. Rivadavia 4702 , Caballito, CABA),
    (null, 57786139, esteticaperlapalermo@gmail.com,Palermo, Av. Santa Fe 3192, Palermo, CABA),
    (null, 57346139, esteticaperlasanmiguel@gmail.com,San Miguel, Av. Presidente Pte. J. D. Perón 1153, San Miguel, GBA);
    
    insert into empleadas VALUES
  -- id, nombreApellido, tipo trabajo y turno
  (null, Carla Acosta,Manicura,Mañana),
  (null, Sofia Casero,Esteticista,Mañana),
  (null, Carmen Verdi,Especialista en pestañas y cejas,Mañana),
  (null, Paloma Rodriguez,Manicura,Tarde),
  (null, Iris Solis,Esteticista,Tarde);

  insert into tratamientos VALUES

  -- idempleeado, idlocal
  (null, Depilación Definitiva,750,'Precio dependiendo la zona. Precio por 3 zonas $1500, por 4 $1800, 
  por 5 zonas $2000, más de 6 zonas $2500',2,5),
  (null, Perfilado de cejas,500,'Perfilado personalizado por la profesional',3,4),
  (null, Extensiones de pestañas,1500,'A partir de $1500. Pestañas 2D, 3D, 4D',3,2),
  (null, Uñas acrilicas,1200,'Tamaño: Cortas, medias(1500) y xl(1800)',4,3),
  (null, Esmaltado Semipermanente,800,Con piedras strass 150 por cada una. 
  Con nail art $250 agregado al precio base,1,1)
  (null, Kapping,900,'Con piedras strass 150 por cada una. Con nail art $250 agregado al precio base',1,1);

  insert into turnos VALUES
  --  precio,idEmpleada,idLocal,idClienta,idTratamiento
  (null,12/10/22,h0900,1500,3,2,1,3), -- extensiones de pestañas
  (null,12/10/22,h1030,500,3,4,2,2),  -- perfilado de cejas
  (null,16/10/22,h1000,1500,1,2,3,3), -- uñas acrilicas
  (null,16/10/22,h1630,800,4,4,4,5), -- semi
  (null,17/10/22,h0900,2500,3,2,5,1); -- depilacion definitiva