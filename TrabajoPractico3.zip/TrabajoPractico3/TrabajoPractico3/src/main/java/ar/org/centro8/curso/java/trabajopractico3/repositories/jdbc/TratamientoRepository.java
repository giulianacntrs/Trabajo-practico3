package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Tratamiento;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTratamiento;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TratamientoRepository;

public class TratamientoRepository implements I_TratamientoRepository {
    private Connection conn;

    public TratamientoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Tratamiento> getAll() {
        List<Tratamiento> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from tratamientos")) {
            while (rs.next()) {
                list.add(new Tratamiento(
                        rs.getInt("idTratamiento"),
                        TipoTratamiento.valueOf(rs.getString("tipoTratamiento")),
                        rs.getDouble("precio"),
                        rs.getString("descripcion"),
                        rs.getInt("idEmpleada"),
                        rs.getInt("idLocal")));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void remove(Tratamiento Tratamiento) {
        if (Tratamiento == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into tratamientos (tipoTratamiento, precio, descripcion, idEmpleada, idLocal) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, Tratamiento.getTipoTratamiento().toString());
            ps.setDouble(2, Tratamiento.getPrecio());
            ps.setString(3, Tratamiento.getdescripcion());
            ps.setInt(4, Tratamiento.getIdEmpleada());
            ps.setInt(5, Tratamiento.getIdLocal());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void save(Tratamiento Tratamiento) {
        if (Tratamiento == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into tratamientos (tipoTratamiento, precio, descripcion, idEmpleada, idLocal) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, Tratamiento.getTipoTratamiento().toString());
            ps.setDouble(2, Tratamiento.getPrecio());
            ps.setString(3, Tratamiento.getdescripcion());
            ps.setInt(4, Tratamiento.getIdEmpleada());
            ps.setInt(5, Tratamiento.getIdLocal());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                Tratamiento.setIdTratamiento(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Tratamiento Tratamiento) {
        if (Tratamiento == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update tratamientos set tipoTratamiento=?, precio=?, descripcion=?, idEmpleada=?, idLocal=?, where idTratamiento=?")) {
            ps.setString(1, Tratamiento.getTipoTratamiento().toString());
            ps.setDouble(2, Tratamiento.getPrecio());
            ps.setString(3, Tratamiento.getdescripcion());
            ps.setInt(4, Tratamiento.getIdEmpleada());
            ps.setInt(5, Tratamiento.getIdLocal());

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
