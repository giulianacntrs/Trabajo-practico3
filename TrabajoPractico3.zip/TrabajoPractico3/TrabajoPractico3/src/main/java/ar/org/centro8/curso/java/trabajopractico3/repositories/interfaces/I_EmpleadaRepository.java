package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;

import ar.org.centro8.curso.java.trabajopractico3.entities.Empleada;
import java.util.ArrayList;
import java.util.List;

public interface I_EmpleadaRepository {
   void save(Empleada empleada);

   void remove(Empleada empleada);

   void update(Empleada empleada);

   default Empleada GetByIdEmpleada(int idEmpleada) {
      return getAll()
            .stream()
            .filter(e -> e.getIdEmpleada() == idEmpleada)
            .findAny()
            .orElse(new Empleada());
   }

   List<Empleada> getAll();
}
