package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;

import ar.org.centro8.curso.java.trabajopractico3.entities.Empleada;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTrabajo;

import java.util.ArrayList;
import java.util.List;

public interface I_EmpleadaRepository {
   void save(Empleada empleada);

   void remove(Empleada empleada);

   void update(Empleada empleada);

   default Empleada getByIdEmpleada(int idEmpleada) {
      return getAll()
            .stream()
            .filter(e -> e.getIdEmpleada() == idEmpleada)
            .findAny()
            .orElse(new Empleada());
   }

   List<Empleada> getAll();

   // nombre
   default List<Empleada> getLikeNombreApellido(String nombreApellido) {
      if (nombreApellido == null)
         return new ArrayList();
      return getAll() // Crea una lista con todos los atributos.
            .stream() // from
            .filter(e -> e.getNombreApellido() != null) // where
            .filter(e -> e // where
                  .getNombreApellido()
                  .toLowerCase()
                  .contains(nombreApellido.toLowerCase()))// otra subcadena
            .toList();
   }

   // tipodetrabajo
   default List<Empleada> getLikeTipoTrabajo(TipoTrabajo tipoTrabajo) {
      if (tipoTrabajo == null)
         return new ArrayList();
      return getAll()
            .stream()
            .filter(e -> e.getTipoTrabajo() == tipoTrabajo.getIdEmpleada())
            .toList();
   }
}