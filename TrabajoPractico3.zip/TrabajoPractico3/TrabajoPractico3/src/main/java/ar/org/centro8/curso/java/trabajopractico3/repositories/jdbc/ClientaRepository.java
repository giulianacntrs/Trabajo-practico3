package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Clienta;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_ClientaRepository;

public class ClientaRepository implements I_ClientaRepository {
    private Connection conn;

    public ClientaRepository(Connection conn) {
        this.conn = conn;
    }
    @Override
    public List<Clienta> getAll() {
        List<Clienta> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from clientas")) {
            while (rs.next()) {
                list.add(new Clienta(
                        rs.getInt("idClienta"),
                        rs.getString("nombreApellido"),
                        rs.getString("telefono"),
                        rs.getString("mail")));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    @Override
    public void remove(Clienta clienta) {
        if (clienta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into clientas (nombreApellido,telefono,mail) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, clienta.getNombreApellido());
            ps.setString(2, clienta.getTelefono());
            ps.setString(3, clienta.getMail());
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public void save(Clienta clienta) {
        if (clienta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into clientas (nombreApellido,telefono,mail) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, clienta.getNombreApellido());
            ps.setString(2, clienta.getTelefono());
            ps.setString(3, clienta.getMail());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                clienta.setidClienta(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public void update(Clienta clienta) {
        if (clienta == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update clientas set nombreApellido=?, telefono=?, mail=?, where idClienta=?")) {
            ps.setString(1, clienta.getNombreApellido());
            ps.setString(2, clienta.getTelefono());
            ps.setString(3, clienta.getMail());
            ps.setInt(3, clienta.getidClienta());

        } catch (Exception e) {
            System.out.println(e);
        }

    }

}
