package ar.org.centro8.curso.java.trabajopractico3.entities;

import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.enums.TurnoTrabajo;

public class Empleada {
    private int idEmpleada;
    private String nombreApellido;
    private TipoTrabajo tipoTrabajo;
    private TurnoTrabajo turnoTrabajo;
    public Object getTipoTrabajo;

    public Empleada() {
    }

    public Empleada(String nombreApellido, TipoTrabajo tipoTrabajo, TurnoTrabajo turnoTrabajo) {
        this.nombreApellido = nombreApellido;
        this.tipoTrabajo = tipoTrabajo;
        this.turnoTrabajo = turnoTrabajo;
    }

    public Empleada(int idEmpleada, String nombreApellido, TipoTrabajo tipoTrabajo, TurnoTrabajo turnoTrabajo) {
        this.idEmpleada = idEmpleada;
        this.nombreApellido = nombreApellido;
        this.tipoTrabajo = tipoTrabajo;
        this.turnoTrabajo = turnoTrabajo;
    }

    @Override
    public String toString() {
        return "Empleada [idEmpleada=" + idEmpleada + ", nombreApellido=" + nombreApellido + ", tipoTrabajo="
                + tipoTrabajo + ", turnoTrabajo=" + turnoTrabajo + "]";
    }

    public int getIdEmpleada() {
        return idEmpleada;
    }

    public void setIdEmpleada(int idEmpleada) {
        this.idEmpleada = idEmpleada;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }

    public TipoTrabajo getTipoTrabajo() {
        return tipoTrabajo;
    }

    public void setTipoTrabajo(TipoTrabajo tipoTrabajo) {
        this.tipoTrabajo = tipoTrabajo;
    }

    public TurnoTrabajo getTurnoTrabajo() {
        return turnoTrabajo;
    }

    public void setTurno(TurnoTrabajo turnoTrabajo) {
        this.turnoTrabajo = turnoTrabajo;
    }

}
