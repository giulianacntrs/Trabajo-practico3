package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Local;
import ar.org.centro8.curso.java.trabajopractico3.enums.Sucursal;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_LocalRepository;


public class LocalRepository implements I_LocalRepository {
    private Connection conn;

    public LocalRepository(Connection conn) {
        this.conn = conn;
    }
    @Override
    public List<Local> getAll() {
        List<Local> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from locales")) {
            while (rs.next()) {
                list.add(new Local(
                        rs.getInt("idLocal"),
                        rs.getString("telefono"),
                        rs.getString("mail"),
                        Sucursal.valueOf(rs.getString("sucursal"))));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    @Override
    public void remove(Local local) {
        if (local == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into locales (telefono,mail,sucursal) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, local.getTelefono());
            ps.setString(2, local.getMail());
            ps.setString(3, local.getSucursal().toString());
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public void save(Local local) {
        if (local == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into locales (telefono,mail,sucursal) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, local.getTelefono());
            ps.setString(2, local.getMail());
            ps.setString(3, local.getSucursal().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                local.setIdLocal(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public void update(Local local) {
        if (local == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update clientas set telefono=?, mail=?, sucursal=?, where idLocal=?")) {
            ps.setString(1, local.getTelefono());
            ps.setString(2, local.getMail());
            ps.setString(3, local.getSucursal().toString());
            ps.setInt(4, local.getIdLocal());

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
