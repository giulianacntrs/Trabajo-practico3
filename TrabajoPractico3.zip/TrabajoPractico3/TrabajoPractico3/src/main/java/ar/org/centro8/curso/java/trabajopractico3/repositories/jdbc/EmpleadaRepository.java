package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Empleada;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.enums.TurnoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_EmpleadaRepository;

public class EmpleadaRepository implements I_EmpleadaRepository {
    private Connection conn;

    public EmpleadaRepository(Connection conn) {
        this.conn = conn;
    }
    @Override
    public List<Empleada> getAll() {
        List<Empleada> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from empleadas")) {
            while (rs.next()) {
                list.add(new Empleada(
                        rs.getInt("idEmpleada"),
                        rs.getString("nombreApellido"),
                        TipoTrabajo.valueOf(rs.getString("tipoTrabajo")),
                        TurnoTrabajo.valueOf(rs.getString("turnoTrabajo"))));
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    @Override
    public void remove(Empleada empleada) {
        if (empleada == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into empleadas (nombreApellido,tipoTrabajo,turnoTrabajo) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, empleada.getNombreApellido());
            ps.setString(2, empleada.getTipoTrabajo().toString());
            ps.setString(3, empleada.getTurnoTrabajo().toString());
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public void save(Empleada empleada) {
        if (empleada == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into empleadas (nombreApellido,tipoTrabajo,turnoTrabajo) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, empleada.getNombreApellido());
            ps.setString(2, empleada.getTipoTrabajo().toString());
            ps.setString(3, empleada.getTurnoTrabajo().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                empleada.setIdEmpleada(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public void update(Empleada empleada) {
        if (empleada == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update clientas set nombreApellido=?, tipoTrabajo=?, turno=?, where idEmpleada=?")) {
            ps.setString(1, empleada.getNombreApellido());
            ps.setString(2, empleada.getTipoTrabajo().toString());
            ps.setString(3, empleada.getTurnoTrabajo().toString());
            ps.setInt(4, empleada.getIdEmpleada());

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
