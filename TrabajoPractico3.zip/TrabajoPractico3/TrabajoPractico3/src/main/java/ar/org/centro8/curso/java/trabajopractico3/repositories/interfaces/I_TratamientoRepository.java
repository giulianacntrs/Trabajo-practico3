package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;

import ar.org.centro8.curso.java.trabajopractico3.entities.Tratamiento;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTratamiento;

import java.util.ArrayList;
import java.util.List;

public interface I_TratamientoRepository {
    void save(Tratamiento tratamiento);

    void remove(Tratamiento tratamiento);

    void update(Tratamiento tratamiento);

    default Tratamiento GetByIdTratamiento(int idTratamiento) {
        return getAll()
                .stream()
                .filter(t -> t.getIdTratamiento() == idTratamiento)
                .findAny()
                .orElse(new Tratamiento());

    }

    List<Tratamiento> getAll();

    // tipodetratamiento
    default List<Tratamiento> getLikeTipoTratamiento(TipoTratamiento tipoTratamiento) {
        if (tipoTratamiento == null)
            return new ArrayList();
        return getAll()
                .stream() // from
                .filter(t -> t.getTipoTratamiento() == tipoTratamiento) // where
                .toList();
    }

    // desc tratamiento

    default List<Tratamiento> getDescTratamiento(String descTratamiento) {
        if (descTratamiento == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(t -> t.getDescTratamiento() == descTratamiento)
                .toList();
    }
}