package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;
import ar.org.centro8.curso.java.trabajopractico3.entities.Turno;
import java.util.ArrayList;
import java.util.List;

public interface I_TurnoRepository {
    void save (Turno turno);
    void remove (Turno turno);
    void update (Turno turno);

    default Turno GetByIdTurno (int idTurno){ 
        return getAll()
        .stream()
        .filter(t->t.getIdTurno()==idTurno)
        .findAny()
        .orElse(new Turno());
    }
    List<Turno>getAll();


    //fecha
    //hora
}
