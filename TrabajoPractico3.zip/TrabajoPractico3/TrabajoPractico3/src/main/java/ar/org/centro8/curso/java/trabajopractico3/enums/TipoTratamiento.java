package ar.org.centro8.curso.java.trabajopractico3.enums;

public enum TipoTratamiento {
    DepilacionDefinitiva, 
    PerfiladoDeCejas, 
    ExtensionesDePestañas, 
    Electrodos, 
    Criolipolisis, 
    UñasAcrilicas, 
    EsmaltadoSemipermanente,
    Kapping
}
