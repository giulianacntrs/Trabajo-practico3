package ar.org.centro8.curso.java.trabajopractico3.repositories;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Date;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.trabajopractico3.connector.Connector;
import ar.org.centro8.curso.java.trabajopractico3.entities.Turno;
import ar.org.centro8.curso.java.trabajopractico3.enums.Hora;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TurnoRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.TurnoRepository;

public class TurnoRepositoryTest {

    I_TurnoRepository turnoRepository = new TurnoRepository(Connector.getConnection());

    @Test
    void testSave() {
        Turno turno1 = new Turno("12-11-22", Hora.h1100, 950, 1, 1, 1, 1);
        Turno turno2 = new Turno("12-11-22", Hora.h1000, 950, 1, 1, 1, 1);
        turnoRepository.save(turno1);
        turnoRepository.save(turno2);

        assertEquals(turno1.getIdTurno() > 0, true);
        assertEquals(turno1.getIdTurno(), turno2.getIdTurno() - 1);
    }

    @Test
    void testGetAll() {
        assertEquals(turnoRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = turnoRepository.getAll().size();
        turnoRepository.remove(turnoRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = turnoRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = turnoRepository.getAll().size();
        Turno turno = turnoRepository.getAll().get(cantidad - 1);
        turno.setFecha("12-11-22");
        turno.setHora(Hora.h1000);
        turno.setPrecio(950);
        turno.setIdEmpleada(1);
        turno.setIdLocal(1);
        turno.setIdClienta(1);
        turno.setIdTratamiento(1);
        turnoRepository.update(turno);
        Turno turno2 = turnoRepository.getAll().get(cantidad - 1);

        assertEquals(turno.getFecha(), turno2.getFecha());
        assertEquals(turno.getHora(), turno2.getHora());
        assertEquals(turno.getPrecio(), turno2.getPrecio());
        assertEquals(turno.getIdEmpleada(), turno2.getIdEmpleada());
        assertEquals(turno.getIdLocal(), turno2.getIdLocal());
        assertEquals(turno.getIdClienta(), turno2.getIdClienta());
        assertEquals(turno.getIdTratamiento(), turno2.getIdTratamiento());

    }
}
