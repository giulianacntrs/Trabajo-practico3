drop database if exists esteticas;
create database esteticas;
use esteticas;

drop table if exists clientes;
drop table if exists locales;
drop table if exists tratamientos;
drop table if exists empleados;
drop table if exists turnos;


CREATE TABLE `esteticas`.`clientes` (
  `idCliente` INT NOT NULL AUTO_INCREMENT,
  `nombreApellido` VARCHAR(70) NULL,
  `telefono` INT NULL,
  `mail` VARCHAR(70) NULL,
  PRIMARY KEY (`idCliente`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_spanish_ci;


CREATE TABLE `esteticas`.`locales` (
  `idLocal` INT NOT NULL AUTO_INCREMENT,
  `telefono` INT NULL,
  `mail` VARCHAR(70) NULL,
  `sucursal` enum ('Belgrano', 'Caballito', 'Morón', 'Palermo', 'San Miguel'),
  `direccion` VARCHAR(70) NULL,
  PRIMARY KEY (`idLocal`));
  
  
  
  CREATE TABLE `esteticas`.`empleados` (
  `idEmpleado` INT NOT NULL AUTO_INCREMENT,
  `nombreApellido` VARCHAR(70) NULL,
  `tipoTrabajo` enum ('Manicura', 'Esteticista', 'Especialista en pestañas y cejas'),
  `turno` enum ('Mañana(09:00hs a 15:00hs)', 'Tarde(15:00hs a 20:00hs)'),
  PRIMARY KEY (`idEmpleado`));
  
  
  CREATE TABLE `esteticas`.`tratamientos` (
  `idTratamiento` INT NOT NULL AUTO_INCREMENT,
  `tipoTratamiento` enum ('Depilación Definitiva', 'Perfilado de cejas', 'Extensiones de pestañas', 
  'Electrodos', 'Criolipolisis', 'Uñas acrilicas', 'Esmaltado Semi/Kapping'),
  `precio` double NULL,
  `descTratamiento` VARCHAR(140) NULL,
  `idEmpleado` INT NULL,
  `idLocal` INT NULL,
  PRIMARY KEY (`idTratamiento`));
  
  
   CREATE TABLE `esteticas`.`turnos` (
  `idTurno` INT NOT NULL AUTO_INCREMENT,
  `fecha` DATE null,
  `hora` enum ('09:00hs', '09:30hs', '10:00hs', '10:30hs', '11:00hs', '11:30hs', '13:00hs', '13:30hs', '14:00hs', 
  '14:30hs', '15:00hs','15:30hs', '16:00hs', '16:30hs', '17:00hs', '17:30hs', '18:00hs', '18:30hs', '19:00hs', '19:30hs'),
  `precio` double NULL,
  `idEmpleado` INT NULL,
  `idLocal` INT NULL,
  `idCliente` INT NULL,
  `idTratamiento` INT NULL,
  PRIMARY KEY (`idTurno`));
  
  alter table turnos 
  add constraint FK_turnos_idCliente
  foreign key (idCliente)
  references clientes(idCliente);
  
    alter table turnos 
  add constraint FK_turnos_idEmpleado
  foreign key (idEmpleado)
  references empleados(idEmpleado);
  
  alter table turnos 
  add constraint FK_turnos_idLocal
  foreign key (idLocal)
  references locales(idLocal);
  
  alter table turnos 
  add constraint FK_turnos_idTrat
  foreign key (idTratamiento)
  references tratamientos(idTratamiento);